# Plan produkcyjny — Gantt (React + Vite + TypeScript)

## Jak uruchomić w StackBlitz / lokalnie
1) Otwórz projekt lub wgraj ZIP do StackBlitz.
2) W terminalu (jeśli trzeba): `npm install`
3) Start dev: `npm run dev` (StackBlitz zrobi to automatycznie).
4) Wciśnij **Demo** albo **Załaduj CSV** (Order No., Resource, Start Time, End Time, opcjonalnie Qty.).

## Build do hostingu
`npm run build` → katalog `dist/` (statyki do publikacji).
